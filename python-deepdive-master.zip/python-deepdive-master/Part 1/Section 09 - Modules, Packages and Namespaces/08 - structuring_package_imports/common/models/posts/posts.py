# posts.py

__all__ = ['Posts']


class Posts:
    pass


def posts_helper_1():
    pass
